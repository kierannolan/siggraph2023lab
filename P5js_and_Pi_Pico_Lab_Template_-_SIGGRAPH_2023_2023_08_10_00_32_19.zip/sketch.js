// p5.js template for the SIGGRAPH 2023 Labs Class: 
// Reactive Visuals in P5.js with Custom Analog and Digital Inputs.
// Kieran Nolan (kieran.nolan@gmail.com, kierannolan.com)


// Links:

// The extended abstract on the ACM Digital Library (with full instructions):
// https://dl.acm.org/doi/10.1145/3588029.3599742

// SIGGRAPH 2023 event page:
// https://s2023.siggraph.org/presentation/?id=gensub_250&sess=sess314

// GitHub Link:
// https://github.com/kierannolan



// ###################################################################
// serial communication with a microcontroller sending multiple values

// don't forget to edit the index.html file and add this to the header:
//  <script language="javascript" type="text/javascript" src="https://cdn.jsdelivr.net/npm/p5.serialserver@0.0.28/lib/p5.serialport.js"></script>

// The following array is 2 variables in one:
// sensors[0] holds the value from the analog sensor (3 to 1023)
// sensors[1] is the 1 or 0 value received from the button
// if you don't have a Pi Pico or Arduino set up, use scroll_value in place of sensors[0]
// pressing any key will substitute for the button press from the Pi Pico or Arduino

let pos = 25;
let scroll_value = 100;
let upper_reset_value = 255;
let lower_reset_value = 0;

let serial; // variable for the serial object
let sensors = [255, 0]; // array to hold data from arduino

function setup() {
  createCanvas(600, 600);

  // serial constructor
  serial = new p5.SerialPort();

  // serial port to use - you'll need to change this
  serial.open("COM4");

  // what to do when we get serial data
  serial.on("data", gotData);

  // when to do when the serial port opens
  serial.on("open", gotOpen);
}

function draw() {
  background(97, 184, 255);

  // if the button is pressed (value = 1) then carry out this loop

  if (sensors[1] == 1 || keyIsPressed === true) {
    console.log("the button was pressed");

    textSize(20);
    textFont("Alfa Slab One");

    background(255, 249, 77);
    text("The button is pressed!", 200, 450);
  }

  // Input variables, use these to dynamically style your background, text and other graphics

  // Analog Sensor Code
  // We are receiving a value between 4 and 1023 from the analog input

  let rotDeg_mouse_scroll = map(scroll_value * 4, 4, 1023, 0.0, 360.0);
  let rotDeg_analog_sensor = map(sensors[0], 4, 1023, 0.0, 360.0);

  // ======================

  // This code draws the dynamic circles.
  // The value sensors[0] changes their size
  // It is a modified version of Example 4-10, Embed One Loop for Another
  // from Getting Started with P5.js (page 51)

  for (var circle_y = 0; circle_y <= height; circle_y += 80) {
    for (var circle_x = 0; circle_x <= width; circle_x += 80) {
      strokeWeight(5);
      stroke(0);
      fill(255, 140);
      circle(circle_x, circle_y, sensors[0]);
    }
  }

  // ======================

  // draw a square, the size is linked to the sensor value

  fill(255, 10, 35);
  noStroke();
  square(200, 200, sensors[0]);

  // Text using Google Fonts
  // Important, remember when referencing Google Fonts in p5.js always replace the + signs in the font names with spaces

  strokeWeight(8);
  stroke(255, 255, 255);

  fill(0, 0, 0);
  textSize(40);
  textFont("Alfa Slab One");
  text("hello", 120, 140);

  textSize(30);
  textFont("Alfa Slab One");
  text("my name is", 160, 170);

  textSize(110);
  textFont("Lobster");
  text("p5.js", 190, 260);

  fill(0, 0, 0);
  textSize(110);
  textFont("Lobster");
  text("Pi Pico", 260, 360);

  textSize(20);
  textFont("Alfa Slab One");
  text("Analog Sensor, sensors[0] - " + sensors[0], 200, 500);
  text("Pushbutton, sensors[1] - " + sensors[1], 200, 530);

  // #################
  // just to note, this is a demo of one way to use the analog sensor (+ mouse scroll) values
  // use the value sensors[0] which reads the analog input on a scale
  // for example, you could have: fill(66, 221, 245, sensors[0]/4);
  // (or: fill(66, 221, 245, scroll_value) if testing with the mouse scroll)
  // to have an RGB colour change opacity. We divide sensors[0] by 4,
  // since opacity is max 256, and the sensors[0] max value is 4 times this.
  // #################

  // End visuals code

  // Console log for the Mousewheel / Trackpad Scroll debug

  if (scroll_value > 255) {
    scroll_value = 255;
    console.log("value over 255, resetting to 255");
  } else if (scroll_value < 0) {
    scroll_value = 0;
    console.log("value under 0, resetting to 0");
  }
}

// Code for communications with the microcontroller

function gotData() {
  let currentString = serial.readLine(); // store the data in a variable
  trim(currentString); // get rid of whitespace
  if (!currentString) return; // if there's nothing in there, ignore it
  sensors = split(currentString, ",");
  console.log(sensors);
  serial.write("A");
}

function gotOpen() {
  print("Serial Port is Open");
  serial.clear(); // clears the buffer of any outstanding data
  serial.write("A"); // send a byte to the Arduino
}

// Mouse Wheel / Trackpad Scroll debug (mirrors the analog sensor input)

function mouseWheel(event) {
  print(event.delta);
  //move the square according to the vertical scroll amount
  pos += event.delta;
  //uncomment to block page scrolling
  //return false;

  //move the square according to the vertical scroll amount
  scroll_value += event.delta / 10;

  console.log(event.delta);
  // this is either -100 or +100, and the direction (up or down) depends on your OS settings
}
